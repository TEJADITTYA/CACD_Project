const messageInput =
    document.getElementById("messageInput");

const charCount =
    document.getElementById("charCount");


messageInput.addEventListener("input", () => {

    charCount.textContent =
        `${messageInput.value.length} characters`;

});


const scamExamples = {

    prize: `Congratulations! 🎉 You have been selected as the lucky winner of ₹50,000.

To claim your prize, send your OTP and UPI details immediately.

Click this link now:
https://bit.ly/claim-reward

Hurry! Your reward expires today.`,



    bank: `URGENT: Your SBI bank account will be blocked today due to incomplete KYC verification.

Verify your account immediately by clicking the link below:

https://sbi-verify-account.example.com

Enter your account number, ATM PIN and OTP to complete verification.`,



    upi: `Your UPI payment of ₹24,999 has been initiated successfully.

If you did not make this transaction, call our customer support immediately at 9876543210.

Share the OTP received on your phone to cancel the transaction.`,



    otp: `Your account has been selected for a security upgrade.

To prevent your account from being suspended, please share the 6-digit OTP sent to your mobile number with our support executive.

This request must be completed within 10 minutes.`,



    job: `Congratulations! Your profile has been shortlisted for a work-from-home job.

You can earn ₹50,000 per month by working only 2 hours a day.

To activate your employee account, pay a refundable registration fee of ₹2,499.

Send the payment screenshot to confirm your position.`,



    delivery: `Your package could not be delivered because your address is incomplete.

Please pay ₹35 delivery verification charges using the link below:

https://delivery-update.example.com

Your package will be returned if payment is not completed within 2 hours.`,



    investment: `Exclusive Investment Opportunity!

Invest ₹5,000 today and receive ₹25,000 guaranteed within 7 days.

Our AI trading system has a 100% success rate.

Limited slots available!

Send your money to the UPI ID below to reserve your account.`,



    tech: `WARNING: Your computer has been infected with a dangerous virus.

Microsoft Security has detected suspicious activity on your device.

Call our technical support immediately at 1800-123-4567.

Do not turn off your computer or your files may be permanently deleted.`,



    loan: `Your personal loan of ₹5,00,000 has been PRE-APPROVED!

Complete your verification today to receive the money instantly.

Pay a processing fee of ₹3,999 to activate your loan.

Click here to complete the process:

https://quick-loan.example.com`,



    social: `Hi! This is the official support team.

We detected unusual activity on your Instagram account.

Your account will be permanently deleted within 24 hours unless you verify your identity.

Send us your password and OTP to restore your account:

https://instagram-security.example.com`

};



function loadSelectedExample() {

    const selected =
        document.getElementById(
            "exampleSelect"
        ).value;


    if (!selected) {

        alert(
            "Please select an example first."
        );

        return;

    }


    const message =
        scamExamples[selected];


    messageInput.value =
        message;


    charCount.textContent =
        `${message.length} characters`;


    /*
       Automatically analyze the
       selected example.
    */

    analyzeMessage();

}


function clearMessage() {

    messageInput.value = "";

    charCount.textContent =
        "0 characters";

    document.getElementById("emptyState")
        .style.display = "flex";

    document.getElementById("resultContent")
        .style.display = "none";

}


async function analyzeMessage() {

    const message =
        messageInput.value.trim();


    if (!message) {

        alert(
            "Please paste a suspicious message first."
        );

        return;
    }


    const button =
        document.querySelector(".analyze-button");


    button.disabled = true;

    button.textContent =
        "🔄 Analyzing...";


    try {

        const response =
            await fetch(
                "http://127.0.0.1:5000/api/analyze",
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({
                        message: message
                    })
                }
            );


        const data =
            await response.json();


        if (!response.ok ||
            !data.success) {

            alert(
                data.error ||
                "Analysis failed."
            );

            return;
        }


        displayResults(
            data.result
        );


    } catch (error) {

        console.error(error);

        alert(
            "Cannot connect to backend. " +
            "Make sure Flask is running."
        );

    } finally {

        button.disabled = false;

        button.textContent =
            "🛡 Analyze Message";

    }

}


function displayResults(result) {

    document.getElementById("emptyState")
        .style.display = "none";


    document.getElementById("resultContent")
        .style.display = "block";


    document.getElementById("riskTitle")
        .textContent =
        result.risk_level + " Risk";


    document.getElementById("riskScore")
        .textContent =
        result.risk_score;


    document.getElementById("summaryText")
        .textContent =
        result.summary;


    document.getElementById(
        "recommendationText"
    ).textContent =
        result.recommendation;


    document.getElementById(
        "riskProgress"
    ).style.width =
        result.risk_score + "%";


    const container =
        document.getElementById(
            "indicators"
        );


    container.innerHTML = "";


    if (
        !result.indicators ||
        result.indicators.length === 0
    ) {

        container.innerHTML = `
            <div class="indicator safe">
                <h4>
                    🟢 No Major Threats Detected
                </h4>

                <p>
                    No significant scam indicators
                    were found.
                </p>
            </div>
        `;

        return;
    }


    result.indicators.forEach(
        indicator => {

            const div =
                document.createElement(
                    "div"
                );

            div.className =
                "indicator";


            div.innerHTML = `
                <h4>
                    ⚠️ ${indicator.type}
                </h4>

                <p>
                    ${indicator.description}
                </p>

                <span>
                    ${indicator.matches.join(", ")}
                </span>
            `;


            container.appendChild(div);

        }
    );

}